# from crypt import methods
# from crypt import methods
from flask import Flask, request, render_template,send_file
import pandas as pd
import requests
from bs4 import BeautifulSoup
import re
from bcr_api.bwproject import BWProject, BWUser
from bcr_api.bwresources import BWQueries, BWGroups, BWAuthorLists, BWSiteLists, BWLocationLists, BWTags, BWCategories, BWRules, BWMentions, BWSignals
import datetime
import logging
import json
import base64
import warnings
warnings.simplefilter('ignore')
from werkzeug.utils import secure_filename
from werkzeug.datastructures import  FileStorage
import numpy as np
from sklearn import preprocessing
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
#Importing tqdm to see progress
from tqdm import tqdm
tqdm.pandas()
from transformers import pipeline
import tensorflow as tf
import os

app = Flask(__name__)

app.config['UPLOAD_FOLDER'] = 'static/data/'
@app.route('/predictionPage')
def prediction(data):
    data = data.columns
    li = list(data)
    return render_template('predictionPage.html',list=li)

#890
@app.route('/890')
def home():
    return render_template('homePage.html')

@app.route('/890data', methods=['POST'])
def data890():
    
    link = request.form['link']
    username = request.form['Username']
    password = request.form['Password']
    appKey = request.form['appKey']
    secretKey = request.form['secretKey']
    data = {"userName":username,"appKey":appKey,"secretKey":secretKey,"password":password,"payload":"small","sinkType":"topic","limit":""}
    payload  = json.dumps(data)
   
    response = requests.post(url=link, json=json.loads(payload))
    json_data=json.loads(response.text)
    decoded_json = json_data.get('data')
    converted_json = [eval(base64.b64decode(x).decode('utf-8')) for x in decoded_json]
    df = pd.DataFrame(converted_json)
    result = df.to_html()
    return  prediction(df)
    
#Amazon
@app.route('/amazonInput')
def amazon():
    return render_template('homeAmazonPage.html')

@app.route('/amazonData', methods=['POST'])
def amazonData():
    
    search_query = request.form['Query']
    print(search_query)
    pages = request.form['Pages'] 
    files = request.form['Files'] 
    
    base_url="https://www.amazon.com/s?k="
    url=base_url+search_query 
        
    header={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36","referer":"https://www.amazon.com/s?k=nike+shoes+men&crid=28WRS5SFLWWZ6&sprefix=nike%2Caps%2C357&ref=nb_sb_ss_organic-diversity_2_4"}
    search_response=requests.get(url,headers=header)
    Cookie={} #insert request cookies within{}
    
    def getAmazonSearch(search_query):
        url="https://www.amazon.com/s?k="+search_query
        page=requests.get(url,headers=header)
        if page.status_code==200:
            return page
        else:
            return "Error"
    
    def Searchasin(asin):
        url="https://www.amazon.com/dp/"+asin
        page=requests.get(url,cookies=Cookie,headers=header)
        if page.status_code==200:
            return page
        else:
            return "Error"
    
    def Searchreviews(review_link):
        url="https://www.amazon.com"+review_link
        page=requests.get(url,cookies=Cookie,headers=header)
        if page.status_code==200:
            return page
        else:
            return "Error"
        
    data_asin=[]
    response=getAmazonSearch(search_query)
    soup=BeautifulSoup(response.content)
    for a in soup.findAll("div",{'class':"sg-col-4-of-12 s-result-item s-asin sg-col-4-of-16 AdHolder sg-col s-widget-spacing-small sg-col-4-of-20"}):
        data_asin.append(a['data-asin'])
        
    link=[]
    for b in range(len(data_asin)):
        response=Searchasin(data_asin[b])
        soup=BeautifulSoup(response.content)
        for b in soup.findAll("a",{'data-hook':"see-all-reviews-link-foot"}):
            link.append(b['href'])
    
    reviews=[]
    date= []
    star=[]
    title=[]
    for f in range(len(link)):
        for z in range(5):
            print(z)
            response=Searchreviews(link[f]+'&pageNumber='+str(z))
            soup=BeautifulSoup(response.content)
            for i,j,k,l in zip(soup.findAll("span",{'data-hook':"review-body"}), soup.findAll("i",{'data-hook':"review-star-rating"}),soup.findAll("span",{'data-hook':"review-date"}),soup.findAll("a",{'data-hook':"product-link"})):
                reviews.append(i.text)
                star.append(j.text) 
                date.append(k.text)
                title.append(l.text)

    rev={"Title":title,'Reviews':reviews,'Date':date,'Star':star}

    review_data=pd.DataFrame.from_dict(rev)
    print(review_data)
    return  prediction(review_data)

#BrandWatch
def apiBrandWatch(search_query,start,end):
    logger = logging.getLogger("bcr_api")
    BWUser(username="abhishek.a.parihar@capgemini.com", password="Capgemini@123", token_path="tokens.txt")
    YOUR_ACCOUNT = 'abhishek.a.parihar@capgemini.com'
    YOUR_PROJECT = 'Demo Projects'

    project = BWProject(username=YOUR_ACCOUNT, project=YOUR_PROJECT)
    queries = BWQueries(project)

    end = (datetime.date(end)).isoformat() + "T05:00:00"
    start = (datetime.date(start)).isoformat() + "T05:00:00"

    filtered = queries.get_mentions(name = search_query,
                            startDate = start, 
                            endDate = end)

    df = pd.DataFrame(filtered)
    
    return df

@app.route('/brandwatchInput')
def brandwatch():
    return render_template('homeBrandWatchPage.html')

@app.route('/brandData', methods=['POST'])
def brandData():
    
    search_query = request.form['Query']
    start = request.form['Start'] 
    end = request.form['End'] 
    
    print(start)
    print(type(start))
    df = apiBrandWatch(search_query,start,end)
    
    return  prediction(df)


#upload page
@app.route('/uploadPage')
def uploadPage():
    return render_template('homeUploadPage.html')

@app.route('/uploadPageData',methods=['POST'])
def uploadPageData():
    
    if request.method == 'POST':
        f = request.files['file']
        global filename
        filename = secure_filename(f.filename)  
        
        f.save(os.path.join(app.config['UPLOAD_FOLDER'], filename)) 
                
        # f.save(secure_filename(f.filename))
        df =  pd.read_csv(app.config['UPLOAD_FOLDER']+filename)
        return  prediction(df)
    
    return prediction(f)

#predict Sentiments
@app.route('/predictSentiments' ,methods=['GET', 'POST'])
def sentiments():
    col_name = request.form.get("list")
    print("hey")
    print(str(col_name))
    # if request.method == "POST":
    #        # getting input with name = fname in HTML form
    #    col_name = request.form.get("list")
    #    print(col_name)
    sentiment_analysis = pipeline("sentiment-analysis")
    
    def clean_text(text):
        text = re.sub(r"[^a-zA-Z0-9.,:!?/\"\']", " ", str(text))
        return text
    
    def get_sentiment(text):
        try:
            sent = sentiment_analysis(text)
        except:
            sent = [{'label' : 'UNKNOWN', 'score':1.0}]
        return sent[0]['label']
    
    def stripped_path(path1):
        s1 = path1
        n=0
        p=0
        for i in range(0,len(s1)):  
            if s1[i]=="/":
                n= n+1
            else:
                pass
            v=n
        for i in range(0,len(s1)):  
            if s1[i]=="/":
                p= p+1
                if p==v:
                    
                    stripped = s1[0:i]
                    video = s1[i+1::]    
            else:
                pass
        return(video,stripped)
    
    def remove_suffix(input_string, suffix):
        if suffix and input_string.endswith(suffix):
            return input_string[:-len(suffix)]
        return(input_string)
    
    def sentiment_req1(file_location, column_name):
        col_name = column_name
        df = pd.read_csv(file_location)
        df['Full Text'] = df[col_name]
        output_path = '_senitment.xlsx'
        df['predicted_sentiment'] = df[column_name].progress_apply(get_sentiment).str.title()
        df.to_excel(output_path)
        return df
    
    global df_predicted
    df_predicted = sentiment_req1(app.config['UPLOAD_FOLDER']+filename,col_name)
    df_predicted.to_excel('Result.xlsx')
    
    negative = len(df_predicted[df_predicted['predicted_sentiment']=='Negative'])
    positive = len(df_predicted[df_predicted['predicted_sentiment']=='Positive'])
    total = len(df_predicted)
    
    
    return render_template('predictionSentiments.html',tables=[df_predicted.to_html(classes='data')], titles=df_predicted.columns.values, 
                           positive=positive,negative=negative,total=total)

@app.route('/result',methods=['GET'])
def download_data():
    if request.method =="GET":
        return send_file('Result.xlsx',as_attachment=True)

#Home
@app.route('/')
def intro():
    return render_template('introPage.html')

if __name__=='__main__':
    app.run(debug=True)
